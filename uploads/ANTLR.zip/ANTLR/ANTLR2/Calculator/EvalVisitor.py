from CalculatorVisitor import CalculatorVisitor
from CalculatorParser import CalculatorParser

class EvalVisitor(CalculatorVisitor):
    def __init__(self):
        self.dictionary = {}
    
    # prog:   stat+ ;
    def visitProg(self, ctx:CalculatorParser.ProgContext):
        statements = ctx.stat()
        for s in statements:
            print(self.visit(s))
            
    # expr ';'                    # exprStatement
    def visitExprStatement(self, ctx:CalculatorParser.ExprStatementContext):
        return self.visit(ctx.expr())
        
    # ID '=' expr ';'             # assignStatement
    def visitAssignStatement(self, ctx:CalculatorParser.AssignStatementContext):
        result = self.visit(ctx.expr())
        variable = ctx.ID().getText()
        self.dictionary[variable] = result
        return result

    # left = expr op=('*'|'/') right = expr  # MulDiv
    def visitMulDiv(self, ctx:CalculatorParser.MulDivContext):
        left = self.visit(ctx.left)
        right = self.visit(ctx.right)
        if ctx.op.type == CalculatorParser.MUL:
            return left * right
        return left / right

    # left = expr op=('+'|'-') right = expr
    def visitAddSub(self, ctx:CalculatorParser.AddSubContext):
        left = self.visit(ctx.left)
        right = self.visit(ctx.right)
        if ctx.op.type == CalculatorParser.ADD:
            return left + right
        return left - right
    
    # <assoc=right> left=expr '^' right=expr     # power   
    def visitPower(self, ctx:CalculatorParser.PowerContext):
        left = self.visit(ctx.left)
        right = self.visit(ctx.right)
        result = 0.0
        result = left ** right
        return result

    # NUMBER
    def visitNumber(self, ctx:CalculatorParser.NumberContext):
        return float(ctx.NUMBER().getText())
        
    # NUMBER
    def visitId(self, ctx:CalculatorParser.NumberContext):
        return float(self.dictionary[ctx.ID().getText()])

    # '(' expr ')'                # parens
    def visitParens(self, ctx:CalculatorParser.ParensContext):
        return self.visit(ctx.expr())
