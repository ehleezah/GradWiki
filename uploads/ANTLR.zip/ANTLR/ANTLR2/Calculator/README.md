# Python Project

This project shows how to handle expressions in Python 3.

```
// manually generate the components (not needed if you use VS Code with the extension)
antlr4 -Dlanguage=Python3 -no-listener -visitor Calculator.g4
// install pip packages
pip install --user antlr4-python3-runtime
// launch the program. The [3] might be added depending on how Python is installed in your system.
python[3] Calculator.py
```