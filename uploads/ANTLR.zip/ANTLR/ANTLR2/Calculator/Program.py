import sys
from antlr4 import *
from CalculatorLexer import CalculatorLexer
from CalculatorParser import CalculatorParser
from EvalVisitor import EvalVisitor

def main(argv):
    # part 1
    input = FileStream(argv[1])
    lexer = CalculatorLexer(input)
    stream = CommonTokenStream(lexer)
    parser = CalculatorParser(stream)
    tree = parser.prog()
        
    # Part 2
    visitor = EvalVisitor()
    visitor.visit(tree)

if __name__ == "__main__":
    main(sys.argv)