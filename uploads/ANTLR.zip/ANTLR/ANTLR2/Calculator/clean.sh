rm *.tokens
rm Calculator*.java
rm Calculator*.py
rm *.class
rm *.pyc
rm *.interp