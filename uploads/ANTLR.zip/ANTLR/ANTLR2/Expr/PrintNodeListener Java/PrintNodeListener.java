import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class PrintNodeListener extends ExprBaseListener {

        @Override
        public void enterProg(ExprParser.ProgContext context)
        {
            System.out.println("PROG:" + context.getText());
        }

        @Override
        public void enterExpr(ExprParser.ExprContext context)
        {
            System.out.println("EXPR:" + context.getText());
        }  
}
