rm *.tokens
rm Expr*.java
rm Expr*.py
rm *.class
rm *.pyc
rm *.interp