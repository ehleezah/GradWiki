import sys
from antlr4 import *
from ExprLexer import ExprLexer
from ExprParser import ExprParser
from ExprListener import ExprListener

def main(argv):
    # part 1
    input = FileStream(argv[1])
    lexer = ExprLexer(input)
    stream = CommonTokenStream(lexer)
    parser = ExprParser(stream)
    tree = parser.prog()
    print(tree.toStringTree(recog=parser))
        
    # Part 2
    lister = ExprListener()
    walker = ParseTreeWalker()
    walker.walk(lister, tree)

if __name__ == "__main__":
    main(sys.argv)