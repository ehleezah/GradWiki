antlr4='java -jar /usr/local/lib/antlr-4.7-complete.jar'
$antlr4 Expr.g4 -Dlanguage=Python3
python Program.py input.txt