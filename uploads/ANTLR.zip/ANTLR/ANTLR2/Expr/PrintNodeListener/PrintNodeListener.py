from ExprListener import ExprListener
from ExprParser import ExprParser

class PrintNodeListener(ExprListener):
    def enterProg(self, ctx:ExprParser.ProgContext):
        print("PROG:" + ctx.getText())
    # Added here
    def enterExpr(self, ctx:ExprParser.ExprContext):
        print("EXPR:" + ctx.getText())

