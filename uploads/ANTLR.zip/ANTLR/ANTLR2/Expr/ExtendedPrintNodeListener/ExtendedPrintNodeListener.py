from ExprListener import ExprListener
from ExprParser import ExprParser

# Comment or uncomment if necessary
class ExtendedPrintNodeListener(ExprListener):
    def enterProg(self, ctx:ExprParser.ProgContext):
        # print("PROG:" + ctx.getText())
        # for child in ctx.getChildren():
        #     print("CHILD:" + child.getText())
        # print("-"*10)
        pass
    def enterExpr(self, ctx:ExprParser.ExprContext):
        # print("EXPR:" + ctx.getText())
        # for child in ctx.getChildren():
        #     print("CHILD:" + child.getText())
        # print("-"*5)
        # if ctx.INT() is not None:
        #     print("INT:" + ctx.INT().getText())
        
        children = list(ctx.getChildren())
        if len(children) == 3 and children[1].getText() == '*':
            print("GOT IT:" + ctx.getText())
