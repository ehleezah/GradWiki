import sys
from antlr4 import *
from ExprLexer import ExprLexer
from ExprParser import ExprParser
from ExtendedPrintNodeListener import ExtendedPrintNodeListener

def main(argv):
    # part 1
    input = FileStream(argv[1])
    lexer = ExprLexer(input)
    stream = CommonTokenStream(lexer)
    parser = ExprParser(stream)
    tree = parser.prog()
        
    # Part 2
    lister = ExtendedPrintNodeListener()
    walker = ParseTreeWalker()
    walker.walk(lister, tree)

if __name__ == "__main__":
    main(sys.argv)