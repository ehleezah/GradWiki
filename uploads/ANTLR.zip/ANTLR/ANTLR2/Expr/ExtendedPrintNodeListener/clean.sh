rm *.tokens
rm Expr*.java
rm Expr*.py
rm *.class
rm *.pyc
rm *.interp
rm -rf __pycache__