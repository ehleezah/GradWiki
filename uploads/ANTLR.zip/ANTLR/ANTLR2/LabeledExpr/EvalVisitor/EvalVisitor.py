from LabeledExprVisitor import LabeledExprVisitor
from LabeledExprParser import LabeledExprParser

class EvalVisitor(LabeledExprVisitor):
    # prog: (expr NEWLINE)* ;
    def visitProg(self, ctx:LabeledExprParser.ProgContext):
        expressions = ctx.expr()
        for e in expressions:
            print(self.visit(e))
        
    # expr op=('*'|'/') expr 
    def visitMulDiv(self, ctx:LabeledExprParser.MulDivContext):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if ctx.op.type == LabeledExprParser.MUL:
            return left * right
        return left / right
    
    # expr op=('+'|'-') expr
    def visitAddSub(self, ctx:LabeledExprParser.AddSubContext):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if ctx.op.type == LabeledExprParser.ADD:
            return left + right
        return left - right
        
    # INT
    def visitInt(self, ctx:LabeledExprParser.AddSubContext):
        return int(ctx.INT().getText())

    # '(' expr ')'                # parens
    def visitParens(self, ctx:LabeledExprParser.ParensContext):
        return self.visit(ctx.expr())
