rm *.tokens
rm LabeledExpr*.java
rm LabeledExpr*.py
rm *.class
rm *.pyc
rm *.interp