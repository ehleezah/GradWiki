from LabeledExprListener import LabeledExprListener
from LabeledExprParser import LabeledExprParser

class PrintNodeListener(LabeledExprListener):
    def enterProg(self, ctx:LabeledExprParser.ProgContext):
        #print(ctx.getText())
        pass
    def enterMulDiv(self, ctx:LabeledExprParser.MulDivContext):
        #print("GOT IT:" + ctx.getText())
        if ctx.op.text == '*':
            print('Multiply operation')