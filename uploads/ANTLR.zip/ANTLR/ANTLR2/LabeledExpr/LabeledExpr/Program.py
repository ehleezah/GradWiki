import sys
from antlr4 import *
from LabeledExprLexer import LabeledExprLexer
from LabeledExprParser import LabeledExprParser
from PrintNodeListener import PrintNodeListener

def main(argv):
    # part 1
    input = FileStream(argv[1])
    lexer = LabeledExprLexer(input)
    stream = CommonTokenStream(lexer)
    parser = LabeledExprParser(stream)
    tree = parser.prog()
    #print(tree.toStringTree(recog=parser))
        
    # Part 2
    lister = PrintNodeListener()
    walker = ParseTreeWalker()
    walker.walk(lister, tree)

if __name__ == "__main__":
    main(sys.argv)