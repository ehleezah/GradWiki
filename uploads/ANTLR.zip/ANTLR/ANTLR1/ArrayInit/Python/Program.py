import sys
from antlr4 import *
from ArrayInitLexer import ArrayInitLexer
from ArrayInitParser import ArrayInitParser
from StringListener import StringListener

def main(argv):
    # part 1
    input = FileStream(argv[1])
    lexer = ArrayInitLexer(input)
    stream = CommonTokenStream(lexer)
    parser = ArrayInitParser(stream)
    tree = parser.init()
    
    # Part 2
    lister = StringListener()
    walker = ParseTreeWalker()
    walker.walk(lister, tree)
    
if __name__ == "__main__":
    main(sys.argv)