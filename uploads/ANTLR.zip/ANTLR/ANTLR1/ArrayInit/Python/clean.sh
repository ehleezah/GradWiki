rm *.tokens
rm ArrayInit*.py
rm *.pyc
rm *.interp
rm -rf __pycache__