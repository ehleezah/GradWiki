import sys
from ArrayInitListener import ArrayInitListener
from ArrayInitParser import ArrayInitParser

# Convert short array inits like {1,2,3} to "\u0001\u0002\u0003" */
class StringListener(ArrayInitListener):
    def enterInit(self, ctx:ArrayInitParser.InitContext):        
        sys.stdout.write('"')
    def exitInit(self, ctx:ArrayInitParser.InitContext):        
        sys.stdout.write('"')
    #value : init | INT
    def enterValue(self, ctx:ArrayInitParser.ValueContext):
        value = int(ctx.INT().getText())
        sys.stdout.write("\\u{}".format(format(value, '04x')));