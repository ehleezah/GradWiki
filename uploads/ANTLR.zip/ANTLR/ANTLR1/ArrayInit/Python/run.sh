antlr4='java -jar /usr/local/lib/antlr-4.7-complete.jar'
$antlr4 ArrayInit.g4 -Dlanguage=Python3
python3 Program.py input.txt