antlr4='java -jar /usr/local/lib/antlr-4.7-complete.jar'
$antlr4 ArrayInit.g4
javac -cp .:/usr/local/lib/antlr-4.7-complete.jar *.java
java -cp .:/usr/local/lib/antlr-4.7-complete.jar Program input.txt
java -cp .:/usr/local/lib/antlr-4.7-complete.jar Program2 input.txt