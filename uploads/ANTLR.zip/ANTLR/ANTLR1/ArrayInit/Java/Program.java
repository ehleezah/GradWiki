/***
 * Excerpted from "The Definitive ANTLR 4 Reference",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material, 
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose. 
 * Visit http://www.pragmaticprogrammer.com/titles/tpantlr2 for more book information.
***/
// import ANTLR's runtime libraries
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.nio.file.Paths;
import java.io.IOException;
import java.io.PrintWriter;

public class Program {

    public static void main( String[] args) {
        try {
            // step 1
            CharStream inputStream = CharStreams.fromPath(Paths.get(args[0]));
            ArrayInitLexer lexer = new ArrayInitLexer(inputStream);
            CommonTokenStream commonTokenStream = new CommonTokenStream(lexer); 
            ArrayInitParser parser = new ArrayInitParser(commonTokenStream);
            ParseTree tree = parser.init();  
            // Check output
            System.out.println(tree.toStringTree(parser));
        } catch (IOException e) {}
    } 
}