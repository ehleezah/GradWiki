antlr4='java -jar /usr/local/lib/antlr-4.7-complete.jar'
grun='java -cp .:/usr/local/lib/antlr-4.7-complete.jar org.antlr.v4.gui.TestRig'
$antlr4 ArrayInit.g4
javac -cp .:/usr/local/lib/antlr-4.7-complete.jar *.java
$grun ArrayInit init -gui