import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.nio.file.Paths;
import java.io.IOException;
import java.io.PrintWriter;

public class Program2 {
    public static void main(String[] args) throws Exception {
        // step1
        CharStream inputStream = CharStreams.fromPath(Paths.get(args[0]));
        ArrayInitLexer lexer = new ArrayInitLexer(inputStream);

        CommonTokenStream tokens = new CommonTokenStream(lexer);
        ArrayInitParser parser = new ArrayInitParser(tokens);
        ParseTree tree = parser.init(); // begin parsing at init rule

        // step 2
        // Create a walker
        ParseTreeWalker walker = new ParseTreeWalker();
        // Walk the tree and invoke listeners
        walker.walk(new StringListener(), tree);
        System.out.println(); // print a \n after translation
    }
}