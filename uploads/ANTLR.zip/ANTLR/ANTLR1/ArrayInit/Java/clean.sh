rm *.tokens
rm ArrayInit*.java
rm *.class
rm *.interp