public class Visitor implements IVisitor {
    private int totalSize = 0;
    public void visit(IHouse house) {
        IRoom[] rooms = house.getRooms();
        for (IRoom room: rooms) room.accept(this);
    }
    public void visit(IRoom room) {
        totalSize += room.getSize();
    }

    public int getTotalSize() {
        return this.totalSize;
    }
}
