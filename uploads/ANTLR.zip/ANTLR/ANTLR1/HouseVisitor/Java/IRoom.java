public interface IRoom {
    public int getSize();
    public void accept(IVisitor visitor);
}
