public class House implements IHouse {
    private IRoom[] rooms;

    public House(IRoom[] rooms) {
        this.rooms = rooms;
    }
    public IRoom[] getRooms() {
        return rooms;
    }
    public void accept(IVisitor visitor) {
        // You can control the accept action, but letting the visitor
        // visit this object is the simplest action
        visitor.visit(this);
    }
}
