public class Room implements IRoom {
    protected int size;

    public Room() {
        this(0);
    }

    public Room(int size) {
        this.size = size;
    }
    public int getSize() {
        return this.size;
    }
    public void accept(IVisitor visitor) {
        visitor.visit(this);
    }
}
