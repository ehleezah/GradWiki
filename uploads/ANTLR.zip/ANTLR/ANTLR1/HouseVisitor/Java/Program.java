public class Program {
    public static void main(String[] args) {
        IRoom[] rooms = new Room[4];
        int[] roomSize = {100, 200, 300};
        for (int i = 0; i < 3; i++) {
            rooms[i] = new BedRoom(roomSize[i]);
        }
        Kitchen kitchen = new Kitchen(400);
        rooms[3] = kitchen;

        House house = new House(rooms);

        Visitor visitor = new Visitor();
        visitor.visit(house);
        // 100 + 200 + 300 + 400*2 = 1400
        System.out.println(visitor.getTotalSize());
    }
}
