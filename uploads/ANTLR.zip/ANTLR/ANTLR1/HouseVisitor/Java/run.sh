javac *.java
java Program