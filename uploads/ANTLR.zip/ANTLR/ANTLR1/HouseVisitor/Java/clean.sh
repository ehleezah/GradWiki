rm *.class
