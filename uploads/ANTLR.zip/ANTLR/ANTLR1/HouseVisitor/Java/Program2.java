public class Program2 {
    public static void main(String[] args) {
        Room[] rooms = new Room[4];
        int[] roomSize = {100, 200, 300};
        for (int i = 0; i < 3; i++) {
            rooms[i] = new Room(roomSize[i]);
        }
        Kitchen kitchen = new Kitchen(400);
        rooms[3] = kitchen;

        House house = new House(rooms);

        Visitor2 visitor = new Visitor2();
        visitor.visit(house);
        System.out.println(visitor.getTotalSize());
    }
}
