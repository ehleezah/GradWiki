public class BedRoom extends Room {
    public BedRoom(int size) {
        super(size);
    }
    @Override
    public int getSize() {
        return super.size * 1;
    }
}