public class Kitchen extends Room {
    public Kitchen(int size) {
        super(size);
    }
    @Override
    public int getSize() {
        return super.size * 2;
    }
}
