public interface IHouse {
    public void accept(IVisitor visitor);
    public IRoom[] getRooms();
}
