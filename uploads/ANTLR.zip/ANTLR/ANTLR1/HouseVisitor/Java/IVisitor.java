public interface IVisitor {
    public void visit(IHouse house);
    public void visit(IRoom room);
}
