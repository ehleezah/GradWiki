class CD(object):
    def __init__(self, price):
        self.price = price

    def accept(self, visitor):
        visitor.visitCD(self)


class Book(object):
    def __init__(self, price):
        self.price = price

    def accept(self, visitor):
        visitor.visitBook(self)


class Visitor(object):
    def __init__(self):
        self.totalPrice = 0.0

    def visitCD(self, cd):
        self.totalPrice += cd.price

    def visitBook(self, book):
        self.totalPrice += book.price

if __name__ == "__main__":
    v = Visitor()
    items = []
    items.append(Book(15)); items.append(CD(20))

    for i in items:
        i.accept(v)
    print(v.totalPrice)
