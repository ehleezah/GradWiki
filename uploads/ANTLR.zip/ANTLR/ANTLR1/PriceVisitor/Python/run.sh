python PriceVisitor.py
