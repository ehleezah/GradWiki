public class PriceVisitor implements Visitor {
    private double totalPrice = 0.0;

    public void visit(Book book) {
        totalPrice += book.getPrice();
    }
    public void visit(CD cd) {
        totalPrice += cd.getPrice();
    }
    public double getTotalPrice() {
        return totalPrice;
    }
}
