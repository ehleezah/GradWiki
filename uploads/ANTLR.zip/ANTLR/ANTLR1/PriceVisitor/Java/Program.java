import java.util.ArrayList;

public class Program {
    public static void main(String[] args) {
        ArrayList<Visitable> items = new ArrayList<Visitable>();
        items.add(new Book(15));
        items.add(new CD(20));

        PriceVisitor pv = new PriceVisitor();
        for (Visitable item: items) {
            item.accept(pv); // this is call a visitor in pv
        }
        System.out.println(pv.getTotalPrice());
    }
}
