public class Book implements Visitable {
    private double price;

    public Book(double price) {
        this.price = price;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public double getPrice() {
        return price;
    }
}
