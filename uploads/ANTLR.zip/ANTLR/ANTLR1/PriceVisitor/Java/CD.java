public class CD implements Visitable {
    private double price;

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public CD(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }
}
