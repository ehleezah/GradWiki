rm *.tokens
rm Hello*.py
rm *.pyc
rm *.interp
rm -rf __pycache__