rm *.tokens
rm Hello*.java
rm *.class
rm *.interp