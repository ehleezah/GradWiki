import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.nio.file.Paths;
import java.io.IOException;
import java.io.PrintWriter;

public class Program {

    public static void main( String[] args) {
        try {
            // step1. generate parse tree
            CharStream inputStream = CharStreams.fromPath(Paths.get(args[0]));
            HelloLexer HelloLexer = new HelloLexer(inputStream);
            CommonTokenStream commonTokenStream = new CommonTokenStream(HelloLexer); 
            HelloParser parser = new HelloParser(commonTokenStream);
            ParseTree tree = parser.greeting(); 

            // step2. use the parse tree
            System.out.println(tree.toStringTree(parser));
            

        } catch (IOException e) {

        }
    } 
}
