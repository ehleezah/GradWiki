import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.nio.file.Paths;
import java.io.IOException;
import java.io.PrintWriter;
// import java.io.BufferedOutputStream;
// import java.io.FileOutputStream;

public class Program {

    public static void main( String[] args) {
        try {
            CharStream inputStream = CharStreams.fromPath(Paths.get(args[0]));
            ChatLexer chatLexer = new ChatLexer(inputStream);
            CommonTokenStream commonTokenStream = new CommonTokenStream(chatLexer); 
            ChatParser chatParser = new ChatParser(commonTokenStream);
            ParseTree tree = chatParser.chat(); 
            //System.out.println(tree.toStringTree(chatParser));

            ParseTreeWalker walker = new ParseTreeWalker();
            

            PrintWriter output = new PrintWriter("output.html");
            HtmlListener htmlChatListener = new HtmlListener(output);
            walker.walk(htmlChatListener, tree);
            output.close(); 

        } catch (IOException e) {

        }
    } 
}

/*

using System;
using System.IO;
using Antlr4.Runtime;
using Antlr4.Runtime.Tree;

namespace SharpListener
{   class Program
    {
        static void Main(string[] args)
        {
            ICharStream chars = CharStreams.fromPath(args[0]);
            ChatLexer lexer = new ChatLexer(chars);            
            CommonTokenStream stream = new CommonTokenStream(lexer);
            ChatParser parser = new ChatParser(stream);
            var tree = parser.chat();

            using (StreamWriter output = new StreamWriter("output.html"))
            {                
                HtmlListener htmlChat = new HtmlListener(output);                
            
                ParseTreeWalker.Default.Walk(htmlChat, tree);
            }
        }
    }
}
*/