import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.PrintWriter;
import java.util.Map;
import java.util.HashMap;

public class HtmlListener extends ChatBaseListener {

        Map<String, String> colors = new HashMap<String, String>(); 
        private PrintWriter output; 
        private Map<ParseTree, String> texts = new HashMap<ParseTree, String>();
        public HtmlListener(PrintWriter output)
        {
            // System.out.println("Hello - constructor");
            this.output = output;
            colorMapConstructor();
        }

        public void colorMapConstructor() {
            colors.put("red", "#ff0000");
            colors.put("pink", "#ffc0cb");
        }

        @Override
        public void enterChat(ChatParser.ChatContext ctx)
        {
            //System.out.println("EnterChat");
            output.println("<html><head><meta charset=\"UTF-8\"/>" + 
                          "<title>Chat Archive</title></head>" + 
                          "<body>");            
        }

        @Override
        public void exitChat(ChatParser.ChatContext ctx)
        {
            //System.out.println("ExitChat");
            output.println("</body></html>");
        }

        @Override
        public void enterLine(ChatParser.LineContext ctx)
        {
            output.println("<p>");
        }

        @Override
        public void exitLine(ChatParser.LineContext ctx)
        {
            output.println("</p>");
        }

        @Override
        public void enterCommand(ChatParser.CommandContext ctx)
        {
            if (ctx.SAYS() != null)
                output.println(": <span>");

            if (ctx.SHOUTS() != null)
                output.println(": <span style=\"text-transform: uppercase\">");
        }

        @Override
        public void exitMessage(ChatParser.MessageContext ctx)
        {
            // message              : 
            // (emoticon | link | color | mention | WORD)+ ;
            String text = "";
        
            for (int i = 0; i < ctx.getChildCount(); i++) {
                ParseTree child = ctx.getChild(i);

                if (texts.containsKey(child)) {
                    text += texts.get(child) + " ";
                } else {
                    text += child.getText() + " ";
                }
            }

            // In this case, we need to store a mapping information
            // color : '/' WORD '/' message '/';
            if (!(ctx.getParent() instanceof ChatParser.LineContext))           
                texts.put(ctx, text);
            else
            // line : name command message NEWLINE ;
            {
                output.println(text);
                output.println("</span>");
            }
        }

        @Override
        public void enterColor(ChatParser.ColorContext ctx)
        {
            // color : '/' WORD '/' message '/';
            String color = ctx.WORD().getText();

            // convert red -> "#ff0000"
            color = colors.get(color);
            String result = String.format("<span style=\"color: %s\">", color);
            //System.out.println(result);
            texts.put(ctx, result);
        }

        @Override
        public void exitColor(ChatParser.ColorContext ctx)
        {
            String message = texts.get(ctx.message());
            texts.put(ctx, texts.get(ctx) + message + "</span>");
        }

        public void exitEmoticon(ChatParser.EmoticonContext ctx)
        {
            String emoticon = ctx.getText();

            if (emoticon.equals(":-)") || emoticon.equals(":)"))
                texts.put(ctx, "🙂 ");                
    
            if (emoticon.equals(":-(") || emoticon.equals(":("))
                texts.put(ctx, "🙁 ");
        }
        
        public void exitLink(ChatParser.LinkContext ctx)
        { 
            // System.out.println(ctx.TEXT().getText());
            // System.out.println(ctx.URL().getText());
            texts.put(ctx, "<a href=\"" + ctx.URL().getText() + "\">"
            + ctx.TEXT().getText().substring(1, ctx.TEXT().getText().length() - 1)
            + "</a>");
        }

        public void exitMention(ChatParser.MentionContext ctx)
        {
            texts.put(ctx, "<a href=\"/user/" + ctx.name().getText() + "\">"
            + "@" + ctx.name().getText() + "</a>");
        }

        public void enterName(ChatParser.NameContext ctx)
        {
            if (ctx.getParent() instanceof ChatParser.LineContext)
                output.print("<strong>");
        }
        public void exitName(ChatParser.NameContext ctx)
        {
            if (ctx.getParent() instanceof ChatParser.LineContext)
            {
                output.print(ctx.getText());
                output.print("</strong>");
            }                        
        }       
}