# Java Project

This project shows how to create and use a listener in C#.

```
// manually generate the components (not needed if you use VS Code with the extension)
antlr4 -listener Chat.g4
java run --configuration Release -- input.txt
```


