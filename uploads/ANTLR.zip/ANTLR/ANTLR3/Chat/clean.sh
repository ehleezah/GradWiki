rm *.tokens
rm Chat*.java
rm Chat*.py
rm *.class
rm *.pyc
rm *.interp
rm output.html