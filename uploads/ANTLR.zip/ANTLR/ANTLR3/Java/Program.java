import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.nio.file.Paths;
import java.io.IOException;
import java.io.PrintWriter;
// import java.io.BufferedOutputStream;
// import java.io.FileOutputStream;

public class Program {

    public static void main( String[] args) {
        try {
            CharStream inputStream = CharStreams.fromPath(Paths.get(args[0]));
            JavaLexer JavaLexer = new JavaLexer(inputStream);
            CommonTokenStream commonTokenStream = new CommonTokenStream(JavaLexer); 
            JavaParser parser = new JavaParser(commonTokenStream);
            ParseTree tree = parser.compilationUnit(); 
            //System.out.println(tree.toStringTree(JavaParser));

            ParseTreeWalker walker = new ParseTreeWalker();
            

//            PrintWriter output = new PrintWriter("output.html");
            ExtractInterfaceListener listener = 
                new ExtractInterfaceListener(parser);
            walker.walk(listener, tree);

        } catch (IOException e) {

        }
    } 
}

/*

using System;
using System.IO;
using Antlr4.Runtime;
using Antlr4.Runtime.Tree;

namespace SharpListener
{   class Program
    {
        static void Main(string[] args)
        {
            ICharStream chars = CharStreams.fromPath(args[0]);
            JavaLexer lexer = new JavaLexer(chars);            
            CommonTokenStream stream = new CommonTokenStream(lexer);
            JavaParser parser = new JavaParser(stream);
            var tree = parser.Java();

            using (StreamWriter output = new StreamWriter("output.html"))
            {                
                HtmlListener htmlJava = new HtmlListener(output);                
            
                ParseTreeWalker.Default.Walk(htmlJava, tree);
            }
        }
    }
}
*/