rm *.tokens
rm Java*.java
rm Java*.py
rm *.class
rm *.pyc
rm *.interp
rm output.html
rm build/*.class